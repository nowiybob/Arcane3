package com.arcana;

import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;

/** Мини-планировщик отложенных задач (в тиках сервера). */
public final class Scheduler {
    private record Task(long at, Runnable run) {}
    private static final List<Task> TASKS = new ArrayList<>();

    public static void later(MinecraftServer server, int delayTicks, Runnable r) {
        TASKS.add(new Task(server.getTicks() + delayTicks, r));
    }

    public static void tick(MinecraftServer server) {
        long now = server.getTicks();
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(t -> { if (t.at <= now) { due.add(t); return true; } return false; });
        for (Task t : due) t.run.run();
    }
}
