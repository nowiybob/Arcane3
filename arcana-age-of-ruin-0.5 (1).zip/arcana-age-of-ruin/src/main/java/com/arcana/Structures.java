package com.arcana;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.Random;

/** Алтари испытаний, арены боссов и тайные подземелья в измерении «Руины». */
public final class Structures {
    private static final BlockState AIR = Blocks.AIR.getDefaultState();

    private static void set(ServerWorld w, int x, int y, int z, Block b) { w.setBlockState(new BlockPos(x, y, z), b.getDefaultState(), Block.NOTIFY_LISTENERS); }
    private static int surface(ServerWorld w, int x, int z) { return w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1; }

    /** Ровная круглая площадка радиуса r на высоте fy. */
    private static void pad(ServerWorld w, int cx, int cz, int fy, int r, BiomeInfo b) {
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            if (dx * dx + dz * dz > r * r) continue;
            int x = cx + dx, z = cz + dz, t = surface(w, x, z);
            for (int y = Math.min(t, fy) - 1; y < fy; y++) set(w, x, y, z, b.floor());
            for (int y = fy + 1; y <= Math.max(t, fy + 7); y++) if (!w.getBlockState(new BlockPos(x, y, z)).isAir()) set(w, x, y, z, Blocks.AIR);
            set(w, x, fy, z, ((dx + dz) & 1) == 0 ? b.floor() : b.accent());
        }
    }

    private static void pillar(ServerWorld w, int x, int fy, int z, int h, BiomeInfo b) {
        for (int i = 1; i <= h; i++) set(w, x, fy + i, z, b.pillar());
        set(w, x, fy + h + 1, z, Blocks.GLOWSTONE);
    }

    public static void altar(ServerWorld w, int cx, int cz, BiomeInfo b) {
        int fy = surface(w, cx, cz);
        pad(w, cx, cz, fy, 6, b);
        for (int sx : new int[]{-4, 4}) for (int sz : new int[]{-4, 4}) pillar(w, cx + sx, fy, cz + sz, 4, b);
        set(w, cx, fy + 1, cz, Blocks.LODESTONE);
    }

    public static void arena(ServerWorld w, int cx, int cz, BiomeInfo b) {
        int fy = surface(w, cx, cz);
        pad(w, cx, cz, fy, 14, b);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            pillar(w, cx + (int) Math.round(Math.cos(a) * 12), fy, cz + (int) Math.round(Math.sin(a) * 12), 6, b);
        }
        set(w, cx, fy + 1, cz, Blocks.CRYING_OBSIDIAN);
        for (int[] o : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) set(w, cx + o[0], fy + 1, cz + o[1], b.accent());
    }

    public static void dungeon(ServerWorld w, int cx, int cz, BiomeInfo b, Random rnd) {
        int sy = surface(w, cx, cz);
        int ry = Math.max(w.getBottomY() + 8, sy - 16); // пол комнаты
        // комната 11x5x11
        for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) for (int dy = -1; dy <= 5; dy++) {
            boolean wall = dx == -5 || dx == 5 || dz == -5 || dz == 5 || dy == -1 || dy == 5;
            Block blk = wall ? (rnd.nextInt(4) == 0 ? b.accent() : b.floor()) : Blocks.AIR;
            set(w, cx + dx, ry + dy, cz + dz, blk);
        }
        for (int[] o : new int[][]{{-4, -4}, {4, -4}, {-4, 4}, {4, 4}}) set(w, cx + o[0], ry + 4, cz + o[1], Blocks.GLOWSTONE);
        // лестница наружу (на восток)
        int depth = sy - ry;
        for (int i = 0; i <= depth + 1; i++) for (int dz = -1; dz <= 1; dz++) for (int h = 0; h < 3; h++)
            set(w, cx + 5 + i, ry + i + h, cz + dz, Blocks.AIR);
        int ex = cx + 5 + depth + 1;
        for (int dz = -1; dz <= 1; dz++) for (int y = ry + depth + 3; y <= surface(w, ex, cz) + 2; y++) set(w, ex, y, cz + dz, Blocks.AIR);
        // сундук с добычей
        BlockPos cp = new BlockPos(cx, ry, cz);
        w.setBlockState(cp, Blocks.CHEST.getDefaultState(), Block.NOTIFY_LISTENERS);
        if (w.getBlockEntity(cp) instanceof ChestBlockEntity chest) {
            int slot = 0;
            String[] res = ModItems.RES[rnd.nextInt(11)];
            chest.setStack(slot++, new ItemStack(ModItems.RESOURCES.get(res[0]), 1 + rnd.nextInt(2)));
            if (rnd.nextInt(3) == 0) {
                ArcanaClass c = ArcanaClass.values()[rnd.nextInt(ArcanaClass.values().length)];
                chest.setStack(slot++, Weapons.create(c, Rarity.of(1 + rnd.nextInt(2))));
            }
            if (rnd.nextInt(2) == 0) chest.setStack(slot++, Artifacts.random(rnd, 2));
            chest.setStack(slot++, new ItemStack(Items.DIAMOND, 2 + rnd.nextInt(5)));
            chest.setStack(slot++, new ItemStack(Items.GOLDEN_APPLE, 1 + rnd.nextInt(2)));
            chest.setStack(slot++, new ItemStack(Items.EXPERIENCE_BOTTLE, 8 + rnd.nextInt(16)));
        }
        // хранители
        EntityType<?>[] pool = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.WITHER_SKELETON, EntityType.PILLAGER};
        for (int i = 0; i < 4; i++) {
            MobEntity m = (MobEntity) pool[rnd.nextInt(pool.length)].create(w);
            if (m == null) continue;
            m.refreshPositionAndAngles(cx + rnd.nextInt(7) - 3 + 0.5, ry + 1, cz + rnd.nextInt(7) - 3 + 0.5, 0, 0);
            m.setCustomName(Text.literal("§7Хранитель подземелья"));
            m.setPersistent();
            EntityAttributeInstance hp = m.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (hp != null) { hp.setBaseValue(hp.getBaseValue() * 3); m.setHealth((float) hp.getBaseValue()); }
            w.spawnEntity(m);
        }
    }
}
