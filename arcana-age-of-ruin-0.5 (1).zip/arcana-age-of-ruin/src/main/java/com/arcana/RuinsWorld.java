package com.arcana;

import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.Random;

/** Измерение «Руины»: переходы, постройка структур рядом с игроками, влияние биомов. */
public final class RuinsWorld {
    public static final RegistryKey<World> KEY = RegistryKey.of(RegistryKeys.WORLD, Identifier.of(ArcanaMod.MOD_ID, "ruins"));
    private static final int CELL = 8; // одна структура на ячейку 8x8 чанков
    private static final int RADIUS = 3;

    public static ServerWorld get(MinecraftServer s) { return s.getWorld(KEY); }
    public static boolean isIn(World w) { return w.getRegistryKey() == KEY; }

    public static BiomeInfo biomeAt(ServerWorld w, BlockPos p) {
        String id = w.getBiome(p).getKey().map(k -> k.getValue().getPath()).orElse("");
        return BiomeInfo.byId(id);
    }

    // ───────────── переходы ─────────────
    public static String travel(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        ServerWorld ruins = get(s);
        if (ruins == null) return "Измерение «Руины» не загружено (проверь, что мод стоит и в логе нет ошибок датапака).";
        if (isIn(p.getWorld())) return "Ты уже в Руинах. Вернуться: /arcana home";
        WorldData.d.home.put(p.getUuidAsString(), new double[]{p.getX(), p.getY(), p.getZ()});
        int x = 0, z = 0;
        int y = ruins.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        p.teleport(ruins, x + 0.5, y + 1, z + 0.5, 0f, 0f);
        Fx.buff(p, StatusEffects.SLOW_FALLING, 10, 0);
        p.sendMessage(Text.literal("§5Ты вошёл в Руины. §7Биомы тут свои: /arcana biome покажет текущий."), false);
        return null;
    }

    public static String home(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        if (!isIn(p.getWorld())) return "Ты не в Руинах.";
        double[] h = WorldData.d.home.get(p.getUuidAsString());
        ServerWorld ow = s.getOverworld();
        if (h == null) { BlockPos sp = ow.getSpawnPos(); h = new double[]{sp.getX() + 0.5, ow.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, sp.getX(), sp.getZ()), sp.getZ() + 0.5}; }
        p.teleport(ow, h[0], h[1], h[2], p.getYaw(), p.getPitch());
        return null;
    }

    // ───────────── тик ─────────────
    private static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    public static void tick(MinecraftServer s) {
        ServerWorld w = get(s);
        if (w == null) return;
        long t = s.getTicks();
        if (t % 6000 == 0) for (BiomeInfo b : BiomeInfo.ALL) WorldData.addInfluence(b.id(), -1); // влияние медленно угасает
        if (t % 6000 == 3000) WorldData.save(s);

        for (ServerPlayerEntity p : w.getPlayers()) {
            if (t % 40 == 0) generateAround(w, p);
            if (t % 100 == 0) hazard(w, p);
        }
    }

    private static void generateAround(ServerWorld w, ServerPlayerEntity p) {
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        for (int cx = pcx - RADIUS; cx <= pcx + RADIUS; cx++) for (int cz = pcz - RADIUS; cz <= pcz + RADIUS; cz++) {
            int cellX = Math.floorDiv(cx, CELL), cellZ = Math.floorDiv(cz, CELL);
            long h = mix(cellX * 341873128712L ^ cellZ * 132897987541L ^ WorldData.d.seed);
            int tx = cellX * CELL + (int) (h & 7), tz = cellZ * CELL + (int) ((h >>> 3) & 7);
            if (cx != tx || cz != tz) continue;
            if (Math.abs(cx) < 3 && Math.abs(cz) < 3) continue; // не трогаем точку входа
            long key = ((long) cx << 32) ^ (cz & 0xFFFFFFFFL);
            if (WorldData.d.done.contains(key)) continue;
            boolean loaded = true;
            for (int dx = -1; dx <= 1 && loaded; dx++) for (int dz = -1; dz <= 1; dz++) if (!w.isChunkLoaded(cx + dx, cz + dz)) { loaded = false; break; }
            if (!loaded) continue;

            int x = cx * 16 + 8, z = cz * 16 + 8;
            BiomeInfo b = biomeAt(w, new BlockPos(x, w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z), z));
            WorldData.d.done.add(key);
            if (b == null) continue;
            Random rnd = new Random(h);
            int roll = (int) ((h >>> 8) % 100);
            if (roll < 30) Structures.altar(w, x, z, b);
            else if (roll < 55) Structures.arena(w, x, z, b);
            else Structures.dungeon(w, x, z, b, rnd);
        }
    }

    // ───────────── влияние биомов ─────────────
    private static void hazard(ServerWorld w, ServerPlayerEntity p) {
        BiomeInfo b = biomeAt(w, p.getBlockPos());
        if (b == null || p.isCreative() || p.isSpectator()) return;
        int inf = WorldData.influence(b.id());
        if (inf >= 70) {
            Fx.buff(p, StatusEffects.REGENERATION, 6, 0);
            if (b.id().equals("forgotten_forest") && p.getRandom().nextInt(6) == 0) {
                MobEntity fox = EntityType.FOX.create(w);
                if (fox != null) { fox.refreshPositionAndAngles(p.getX() + 3, p.getY(), p.getZ() + 3, 0, 0); w.spawnEntity(fox); }
            }
            return;
        }
        if (inf >= 40) return;
        int amp = inf < 15 ? 1 : 0;
        switch (b.id()) {
            case "permafrost" -> { p.setFrozenTicks(p.getFrozenTicks() + 140); if (amp > 0) Fx.buff(p, StatusEffects.SLOWNESS, 5, 0); }
            case "ash_wasteland" -> { if (!p.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) p.setOnFireFor(2 + amp * 2); }
            case "forgotten_forest" -> Fx.buff(p, StatusEffects.WEAKNESS, 6, amp);
            case "void" -> Fx.buff(p, StatusEffects.DARKNESS, 6, 0);
            case "sky_islands" -> { if (p.getRandom().nextInt(3) == 0) Fx.buff(p, StatusEffects.LEVITATION, 2, 0); }
            case "sunken_kingdom" -> Fx.buff(p, StatusEffects.NAUSEA, 6, 0);
            case "thunder_peaks" -> {
                LightningEntity l = EntityType.LIGHTNING_BOLT.create(w);
                if (l != null && p.getRandom().nextInt(2) == 0) {
                    l.refreshPositionAfterTeleport(p.getPos().add((p.getRandom().nextDouble() - 0.5) * 16, 0, (p.getRandom().nextDouble() - 0.5) * 16));
                    w.spawnEntity(l);
                }
            }
            case "golden_sands" -> { Fx.buff(p, StatusEffects.SLOWNESS, 5, 0); Fx.buff(p, StatusEffects.HUNGER, 5, amp); }
            case "crimson_swamps" -> Fx.buff(p, StatusEffects.POISON, 4, 0);
            case "crystal_depths" -> Fx.buff(p, StatusEffects.MINING_FATIGUE, 6, amp);
            case "dead_lands" -> Fx.buff(p, StatusEffects.WITHER, 3, 0);
            default -> {}
        }
    }

    public static void onBossKilled(String bossId) {
        BiomeInfo b = BiomeInfo.byBoss(bossId);
        if (b != null) WorldData.addInfluence(b.id(), 40);
    }

    public static String describe(ServerPlayerEntity p) {
        if (!isIn(p.getWorld())) return "Ты не в Руинах. Войти: /arcana travel";
        BiomeInfo b = biomeAt((ServerWorld) p.getWorld(), p.getBlockPos());
        if (b == null) return "Биом не распознан.";
        int inf = WorldData.influence(b.id());
        String state = inf >= 70 ? "§aблагословлён" : inf >= 40 ? "§eспокоен" : "§cиспорчен";
        return "§6" + b.name() + " §7— влияние §f" + inf + "/100 (" + state + "§7)"
                + "\n§7Босс: §f" + Bosses.DEFS.get(b.boss()).name()
                + "\n§7Испытание подходит: §f" + b.suitsText()
                + "\n§8Победа над боссом даёт +40 влияния, со временем влияние угасает. Ниже 40 биом опасен, от 70 — лечит.";
    }
}
