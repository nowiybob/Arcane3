package com.arcana;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.UUID;

public class ArcanaMod implements ModInitializer {
    public static final String MOD_ID = "arcana";

    public static final AttachmentType<PlayerData> DATA = AttachmentRegistry.create(
            Identifier.of(MOD_ID, "player_data"),
            b -> b.persistent(PlayerData.CODEC).copyOnDeath().initializer(() -> PlayerData.EMPTY));

    public static final AttachmentType<PetsData> PETS = AttachmentRegistry.create(
            Identifier.of(MOD_ID, "pets"),
            b -> b.persistent(PetsData.CODEC).copyOnDeath().initializer(() -> PetsData.EMPTY));

    public static final AttachmentType<ArtData> ARTS = AttachmentRegistry.create(
            Identifier.of(MOD_ID, "artifacts"),
            b -> b.persistent(ArtData.CODEC).copyOnDeath().initializer(() -> ArtData.EMPTY));

    @Override
    public void onInitialize() {
        ModItems.init();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Scheduler.tick(server);
            CastManager.tick(server);
            Minions.tick(server);
            Bosses.tick(server);
            FallOfCreation.tick(server);
            RuinsWorld.tick(server);
            Trials.tick(server);
            Pets.tick(server);
            Artifacts.tick(server);
        });

        ServerLifecycleEvents.SERVER_STARTED.register(WorldData::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(WorldData::save);

        // Алтарь (Lodestone) — классовое испытание, Плачущий обсидиан — вызов босса биома
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp) || !RuinsWorld.isIn(world)) return ActionResult.PASS;
            var pos = hit.getBlockPos();
            if (world.getBlockState(pos).isOf(Blocks.LODESTONE)) { Trials.start(sp, pos); return ActionResult.SUCCESS; }
            if (world.getBlockState(pos).isOf(Blocks.CRYING_OBSIDIAN)) { Sigils.use(sp, pos); return ActionResult.SUCCESS; }
            return ActionResult.PASS;
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> Commands.register(dispatcher));

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> { Progression.applyStats(handler.player); Guilds.updateRating(handler.player); });
        ServerPlayerEvents.AFTER_RESPAWN.register((old, neu, alive) -> Progression.applyStats(neu));

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            // Фантом: нет урона от падения
            if (entity instanceof ServerPlayerEntity p && source.isOf(DamageTypes.FALL)
                    && CastManager.cls(p) == ArcanaClass.PHANTOM) return false;
            // Артефакт уклонения
            if (entity instanceof ServerPlayerEntity dp && source.getAttacker() != null) {
                double dodge = Artifacts.sum(dp, Artifacts.Kind.DODGE);
                if (dodge > 0 && dp.getRandom().nextDouble() < dodge) {
                    Fx.puff(dp.getServerWorld(), net.minecraft.particle.ParticleTypes.LARGE_SMOKE, dp.getPos().add(0, 1, 0), 15, 0.4, 0.05);
                    return false;
                }
            }
            // Свои не бьют своих: игрок, его миньоны
            if (source.getAttacker() != null) {
                UUID a = Minions.ownerOf(source.getAttacker()), v = Minions.ownerOf(entity);
                if (a != null && a.equals(v)) return false;
            }
            return true;
        });

        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damageTaken, blocked) -> {
            var server = entity.getServer();
            if (server == null) return;
            Bosses.onDamage(entity, source, damageTaken, server);

            // Титан: ярость при получении урона
            if (entity instanceof ServerPlayerEntity p && damageTaken > 0 && CastManager.cls(p) == ArcanaClass.TITAN)
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 100, 0));

            if (source.getAttacker() instanceof ServerPlayerEntity a && a != entity) {
                ArcanaClass c = CastManager.cls(a);
                if (c == ArcanaClass.DRAGONOR) CastManager.addMana(a, 3);
                if (c == ArcanaClass.STORMCALLER) a.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 0));
                if (c == ArcanaClass.RANGER) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100, 0));
            }
            // Ледяной волк призывателя замедляет
            if (source.getAttacker() != null && source.getAttacker().getCommandTags().contains("arcana_ice"))
                entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            var server = entity.getServer();
            if (server == null || entity instanceof ServerPlayerEntity) return;
            if (entity.getCommandTags().contains("arcana_decoy"))
                Illusions.burst((net.minecraft.server.world.ServerWorld) entity.getWorld(), Minions.ownerPlayer(server, entity), entity.getPos());
            if (entity.getCommandTags().contains("arcana_event_mob")) FallOfCreation.onMobKilled(server);
            Trials.onKill(server, entity);
            if (Bosses.isBoss(entity) || Minions.isMinion(entity)) return;
            ServerPlayerEntity killer = Minions.ownerPlayer(server, source.getAttacker());
            if (killer == null) return;
            if (entity instanceof HostileEntity || entity.getCommandTags().contains("arcana_event_mob")) {
                int xp = (int) Math.max(1, Math.min(200, entity.getMaxHealth() / 2));
                if (entity.getCommandTags().contains("arcana_event_mob")) xp *= 2;
                Progression.giveXp(killer, xp);
                Pets.addXp(killer, xp / 2 + 1);
                Guilds.onKill(killer);
            }
            if (CastManager.cls(killer) == ArcanaClass.NECROMANCER) CastManager.addMana(killer, 5);
            double souls = Artifacts.sum(killer, Artifacts.Kind.SOULS);
            if (souls > 0) CastManager.addMana(killer, souls);
        });
    }
}
