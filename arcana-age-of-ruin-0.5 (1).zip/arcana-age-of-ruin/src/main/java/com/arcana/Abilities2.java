package com.arcana;

import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Классы 5–12. Числа урона/КД из описания; остальное — рабочие значения (см. README). */
public final class Abilities2 {

    // ───────────── helpers ─────────────
    private static void bolt(ServerWorld w, ServerPlayerEntity by, Vec3d pos) {
        LightningEntity b = EntityType.LIGHTNING_BOLT.create(w);
        if (b == null) return;
        b.refreshPositionAfterTeleport(pos);
        b.setChanneler(by);
        w.spawnEntity(b);
    }

    private static void freeze(ServerWorld w, LivingEntity e, int sec) {
        Fx.buff(e, StatusEffects.SLOWNESS, sec, 9);
        Fx.buff(e, StatusEffects.WEAKNESS, sec, 1);
        if (e instanceof MobEntity m) {
            m.setAiDisabled(true);
            Scheduler.later(w.getServer(), sec * 20, () -> { if (m.isAlive()) m.setAiDisabled(false); });
        }
        Fx.puff(w, ParticleTypes.ENCHANT, Fx.center(e), 20, 0.4, 0.5);
    }

    private static void pulses(ServerWorld w, int count, int interval, Runnable r) {
        MinecraftServer s = w.getServer();
        for (int i = 0; i < count; i++) Scheduler.later(s, i * interval, r);
    }

    // ───────────── СОЛАРИС ─────────────
    public static final List<Ability> SOLARIS = List.of(
        new Ability("Солнечный разрез", "40 урона врагам перед вами (нежити ×1.5)", 10, 15, false, (p, w) -> {
            List<LivingEntity> ts = Fx.along(p, 6, 1.3);
            if (ts.isEmpty()) return false;
            for (LivingEntity t : ts) {
                Fx.magic(t, p, t.getType().isIn(EntityTypeTags.UNDEAD) ? 60f : 40f);
                t.setOnFireFor(2);
            }
            Fx.beam(w, ParticleTypes.END_ROD, p.getEyePos().add(0, -0.3, 0), p.getEyePos().add(p.getRotationVec(1f).multiply(5)));
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f);
            return true;
        }),
        new Ability("Луч рассвета", "лечит союзников в радиусе 10", 30, 25, false, (p, w) -> {
            for (ServerPlayerEntity a : Fx.allies(w, p, 10)) {
                a.heal(8f);
                Fx.buff(a, StatusEffects.REGENERATION, 5, 1);
                Fx.puff(w, ParticleTypes.HAPPY_VILLAGER, a.getPos().add(0, 1, 0), 15, 0.4, 0.1);
            }
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.2f);
            return true;
        }),
        new Ability("Священный барьер", "защищает команду: Поглощение и Сопротивление", 40, 25, false, (p, w) -> {
            for (ServerPlayerEntity a : Fx.allies(w, p, 10)) {
                Fx.buff(a, StatusEffects.ABSORPTION, 10, 1);
                Fx.buff(a, StatusEffects.RESISTANCE, 6, 0);
                Fx.puff(w, ParticleTypes.GLOW, a.getPos().add(0, 1, 0), 25, 0.5, 0.05);
            }
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, 1.3f);
            return true;
        }),
        new Ability("Кара солнца", "врагам в радиусе 8: 15 урона, нежити 50 и поджог", 35, 30, false, (p, w) -> {
            List<LivingEntity> es = Fx.around(w, p.getPos(), 8, p);
            for (LivingEntity e : es) {
                boolean undead = e.getType().isIn(EntityTypeTags.UNDEAD);
                Fx.magic(e, p, undead ? 50f : 15f);
                if (undead) e.setOnFireFor(6);
                Fx.puff(w, ParticleTypes.FLAME, Fx.center(e), 15, 0.3, 0.05);
            }
            Fx.puff(w, ParticleTypes.END_ROD, p.getPos().add(0, 2, 0), 80, 3, 0.1);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 0.8f);
            return true;
        }),
        new Ability("Солнце над миром", "15 сек: область света усиливает союзников и жжёт нежить", 120, 80, true, (p, w) -> {
            Vec3d c = p.getPos();
            pulses(w, 15, 20, () -> {
                for (ServerPlayerEntity a : w.getPlayers(x -> x.isAlive() && x.squaredDistanceTo(c) <= 144)) {
                    Fx.buff(a, StatusEffects.STRENGTH, 3, 0);
                    Fx.buff(a, StatusEffects.REGENERATION, 3, 0);
                    Fx.buff(a, StatusEffects.SPEED, 3, 0);
                }
                for (LivingEntity e : Fx.around(w, c, 12, p)) {
                    if (e.getType().isIn(EntityTypeTags.UNDEAD)) { Fx.magic(e, p, 10f); e.setOnFireFor(3); }
                    else Fx.buff(e, StatusEffects.WEAKNESS, 2, 0);
                }
                Fx.puff(w, ParticleTypes.END_ROD, c.add(0, 4, 0), 40, 6, 0.02);
            });
            Fx.sound(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.5f);
            return true;
        })
    );

    // ───────────── НЕКРОМАНТ ─────────────
    public static final List<Ability> NECROMANCER = List.of(
        new Ability("Душа мертвеца", "призывает скелета-лучника на 60 сек", 15, 20, false, (p, w) -> {
            Minions.spawn(p, EntityType.SKELETON, "Душа мертвеца", 60, 1.0, true);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_WITHER_SPAWN, 1.6f);
            return true;
        }),
        new Ability("Проклятие", "8 урона в секунду в течение 8 сек", 20, 25, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 15);
            if (t == null) return false;
            for (int i = 1; i <= 8; i++) Scheduler.later(w.getServer(), i * 20, () -> {
                if (t.isAlive()) { Fx.magic(t, p, 8f); Fx.puff(w, ParticleTypes.SOUL, Fx.center(t), 8, 0.3, 0.02); }
            });
            Fx.sound(w, t.getPos(), SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, 0.7f);
            return true;
        }),
        new Ability("Костяная стена", "защитная преграда из костей на 8 сек", 25, 20, false, (p, w) -> {
            Vec3d d = p.getRotationVec(1f);
            Vec3d h = new Vec3d(d.x, 0, d.z).normalize();
            boolean alongZ = Math.abs(h.x) > Math.abs(h.z);
            BlockPos base = BlockPos.ofFloored(p.getPos().add(h.multiply(4)));
            List<BlockPos> placed = new ArrayList<>();
            for (int s = -2; s <= 2; s++) for (int y = 0; y < 3; y++) {
                BlockPos bp = base.add(alongZ ? 0 : s, y, alongZ ? s : 0);
                if (w.getBlockState(bp).isAir()) { w.setBlockState(bp, Blocks.BONE_BLOCK.getDefaultState()); placed.add(bp); }
            }
            Scheduler.later(w.getServer(), 160, () -> {
                for (BlockPos bp : placed) if (w.getBlockState(bp).isOf(Blocks.BONE_BLOCK)) w.setBlockState(bp, Blocks.AIR.getDefaultState());
            });
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BONE_BLOCK_PLACE, 0.8f);
            return !placed.isEmpty();
        }),
        new Ability("Поглощение души", "15 урона врагам в радиусе 6, +10 маны за каждого (до 40)", 30, 15, false, (p, w) -> {
            List<LivingEntity> es = Fx.around(w, p.getPos(), 6, p);
            if (es.isEmpty()) return false;
            int gained = 0;
            for (LivingEntity e : es) {
                Fx.magic(e, p, 15f);
                if (gained < 40) { gained += 10; CastManager.addMana(p, 10); }
                p.heal(1f);
                Fx.beam(w, ParticleTypes.SOUL_FIRE_FLAME, Fx.center(e), p.getEyePos());
            }
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_VEX_CHARGE, 0.8f);
            return true;
        }),
        new Ability("Мёртвое королевство", "призывает армию нежити на 30 сек", 120, 80, true, (p, w) -> {
            for (int i = 0; i < 6; i++) Minions.spawn(p, EntityType.SKELETON, "Воин королевства", 30, 1.0, i % 2 == 0);
            for (int i = 0; i < 3; i++) Minions.spawn(p, EntityType.ZOMBIE, "Страж королевства", 30, 1.0, false);
            Fx.puff(w, ParticleTypes.SOUL_FIRE_FLAME, p.getPos(), 100, 2.5, 0.1);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_WITHER_SPAWN, 0.7f);
            return true;
        })
    );

    // ───────────── ПРИЗЫВАТЕЛЬ ─────────────
    private static void fireSpirit(ServerPlayerEntity p) { Minions.spawn(p, EntityType.BLAZE, "Дух огня", 30, 1.0, false); }
    private static void stoneGuard(ServerPlayerEntity p) {
        MobEntity g = Minions.spawn(p, EntityType.IRON_GOLEM, "Каменный страж", 40, 1.0, false);
        if (g != null) Fx.buff(g, StatusEffects.RESISTANCE, 40, 1);
    }
    private static void iceWolf(ServerPlayerEntity p) {
        MobEntity wolf = Minions.spawn(p, EntityType.WOLF, "Ледяной волк", 40, 1.2, false);
        if (wolf != null) { Fx.buff(wolf, StatusEffects.STRENGTH, 40, 2); Fx.buff(wolf, StatusEffects.SPEED, 40, 1); wolf.addCommandTag("arcana_ice"); }
    }
    private static void windSpirit(ServerPlayerEntity p, ServerWorld w) {
        for (ServerPlayerEntity a : Fx.allies(w, p, 10)) {
            Fx.buff(a, StatusEffects.SPEED, 10, 1);
            Fx.puff(w, ParticleTypes.CLOUD, a.getPos().add(0, 1, 0), 20, 0.4, 0.1);
        }
    }

    public static final List<Ability> SUMMONER = List.of(
        new Ability("Дух огня", "атакующий помощник на 30 сек", 20, 20, false, (p, w) -> { fireSpirit(p); return true; }),
        new Ability("Каменный страж", "защитник-голем на 40 сек", 25, 20, false, (p, w) -> { stoneGuard(p); return true; }),
        new Ability("Ледяной волк", "быстрый волк, замедляющий врагов, 40 сек", 25, 20, false, (p, w) -> { iceWolf(p); return true; }),
        new Ability("Дух ветра", "ускоряет союзников в радиусе 10 на 10 сек", 30, 20, false, (p, w) -> {
            windSpirit(p, w);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PHANTOM_FLAP, 1.5f);
            return true;
        }),
        new Ability("Древний легион", "призывает всех четырёх духов сразу", 120, 80, true, (p, w) -> {
            fireSpirit(p); stoneGuard(p); iceWolf(p); windSpirit(p, w);
            Fx.puff(w, ParticleTypes.END_ROD, p.getPos().add(0, 1, 0), 100, 2, 0.2);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.4f);
            return true;
        })
    );

    // ───────────── БУРЕВЕСТНИК ─────────────
    public static final List<Ability> STORMCALLER = List.of(
        new Ability("Грозовой выпад", "35 урона цели в радиусе 10", 8, 15, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 10);
            if (t == null) return false;
            Fx.magic(t, p, 35f);
            Fx.beam(w, ParticleTypes.ELECTRIC_SPARK, p.getEyePos().add(0, -0.2, 0), Fx.center(t));
            Fx.sound(w, t.getPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 1.5f);
            return true;
        }),
        new Ability("Молниеносный рывок", "быстрый рывок вперёд, бьёт врагов на пути", 15, 15, false, (p, w) -> {
            Vec3d d = p.getRotationVec(1f);
            for (LivingEntity e : Fx.along(p, 6, 1.2)) Fx.magic(e, p, 20f);
            p.setVelocity(d.x * 1.8, Math.max(0.2, d.y * 1.2), d.z * 1.8);
            p.velocityModified = true;
            p.fallDistance = 0;
            Fx.buff(p, StatusEffects.SPEED, 3, 1);
            Fx.beam(w, ParticleTypes.ELECTRIC_SPARK, p.getPos().add(0, 1, 0), p.getPos().add(d.multiply(6)).add(0, 1, 0));
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 1.8f);
            return true;
        }),
        new Ability("Штормовой купол", "8 сек: электрическая защита бьёт врагов рядом", 35, 25, false, (p, w) -> {
            Fx.buff(p, StatusEffects.RESISTANCE, 8, 0);
            pulses(w, 16, 10, () -> {
                if (!p.isAlive()) return;
                for (LivingEntity e : Fx.around(w, p.getPos(), 4, p)) Fx.magic(e, p, 5f);
                Fx.puff(w, ParticleTypes.ELECTRIC_SPARK, p.getPos().add(0, 1, 0), 30, 2, 0.2);
            });
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, 1.8f);
            return true;
        }),
        new Ability("Громовой раскат", "молнии бьют до 6 врагов в радиусе 12", 30, 30, false, (p, w) -> {
            List<LivingEntity> es = Fx.around(w, p.getPos(), 12, p);
            if (es.isEmpty()) return false;
            int n = 0;
            for (LivingEntity e : es) {
                if (n++ >= 6) break;
                Fx.magic(e, p, 25f);
                bolt(w, p, e.getPos());
            }
            return true;
        }),
        new Ability("Сердце бури", "12 сек: живая молния — скорость, сила, удары по врагам", 120, 80, true, (p, w) -> {
            Fx.buff(p, StatusEffects.SPEED, 12, 2);
            Fx.buff(p, StatusEffects.STRENGTH, 12, 1);
            Fx.buff(p, StatusEffects.RESISTANCE, 12, 0);
            pulses(w, 12, 20, () -> {
                if (!p.isAlive()) return;
                for (LivingEntity e : Fx.around(w, p.getPos(), 8, p)) { Fx.magic(e, p, 20f); Fx.puff(w, ParticleTypes.ELECTRIC_SPARK, Fx.center(e), 15, 0.3, 0.2); }
                Fx.puff(w, ParticleTypes.ELECTRIC_SPARK, p.getPos().add(0, 1, 0), 60, 0.8, 0.3);
            });
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1f);
            return true;
        })
    );

    // ───────────── РЕЙНДЖЕР ─────────────
    public static final List<Ability> RANGER = List.of(
        new Ability("Пронзающий выстрел", "45 урона всем на линии до 40 блоков", 8, 15, false, (p, w) -> {
            Vec3d end = Fx.aimPoint(p, 40);
            double range = Math.min(40, p.getEyePos().distanceTo(end));
            Fx.beam(w, ParticleTypes.CRIT, p.getEyePos().add(0, -0.2, 0), end);
            for (LivingEntity t : Fx.along(p, range, 0.7)) Fx.magic(t, p, 45f);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_ARROW_SHOOT, 0.8f);
            return true;
        }),
        new Ability("Ловушка охотника", "ловушка в точке прицела на 20 сек: обездвиживает первого вошедшего", 25, 20, false, (p, w) -> {
            Vec3d c = Fx.aimPoint(p, 10);
            boolean[] fired = {false};
            for (int i = 0; i < 80; i++) Scheduler.later(w.getServer(), i * 5, () -> {
                if (fired[0]) return;
                Fx.puff(w, ParticleTypes.CRIT, c.add(0, 0.1, 0), 2, 0.5, 0);
                for (LivingEntity e : Fx.around(w, c, 2, p)) {
                    if (Minions.ownerOf(e) != null) continue;
                    fired[0] = true;
                    Fx.buff(e, StatusEffects.SLOWNESS, 5, 6);
                    Fx.buff(e, StatusEffects.WEAKNESS, 5, 0);
                    Fx.magic(e, p, 10f);
                    Fx.sound(w, c, SoundEvents.BLOCK_CHAIN_PLACE, 1f);
                    break;
                }
            });
            return true;
        }),
        new Ability("Орлиный взгляд", "подсвечивает врагов в радиусе 40 на 10 сек", 30, 15, false, (p, w) -> {
            for (LivingEntity e : Fx.around(w, p.getPos(), 40, p)) Fx.buff(e, StatusEffects.GLOWING, 10, 0);
            Fx.buff(p, StatusEffects.NIGHT_VISION, 10, 0);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PHANTOM_AMBIENT, 1.5f);
            return true;
        }),
        new Ability("Зов зверя", "призывает волка на 40 сек", 40, 25, false, (p, w) -> {
            MobEntity wolf = Minions.spawn(p, EntityType.WOLF, "Волк охотника", 40, 1.2, false);
            if (wolf != null) Fx.buff(wolf, StatusEffects.STRENGTH, 40, 1);
            return true;
        }),
        new Ability("Последний выстрел", "200 урона по линии на огромную дальность (80 блоков)", 120, 80, true, (p, w) -> {
            Vec3d end = Fx.aimPoint(p, 80);
            double range = Math.min(80, p.getEyePos().distanceTo(end));
            Fx.beam(w, ParticleTypes.END_ROD, p.getEyePos().add(0, -0.2, 0), end);
            for (LivingEntity t : Fx.along(p, range, 0.9)) Fx.magic(t, p, 200f);
            Fx.puff(w, ParticleTypes.EXPLOSION, end, 3, 0.5, 0);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.5f);
            return true;
        })
    );

    // ───────────── АЛХИМИК ─────────────
    public static final List<Ability> ALCHEMIST = List.of(
        new Ability("Кислотная смесь", "30 урона и отравление", 10, 15, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 12);
            if (t == null) return false;
            Fx.magic(t, p, 30f);
            Fx.buff(t, StatusEffects.POISON, 5, 1);
            Fx.beam(w, ParticleTypes.HAPPY_VILLAGER, p.getEyePos().add(0, -0.3, 0), Fx.center(t));
            Fx.sound(w, t.getPos(), SoundEvents.ENTITY_SPLASH_POTION_BREAK, 1f);
            return true;
        }),
        new Ability("Взрывная колба", "50 урона в радиусе 4 от точки прицела", 15, 25, false, (p, w) -> {
            Vec3d c = Fx.aimPoint(p, 15);
            for (LivingEntity e : Fx.around(w, c, 4, p)) {
                Fx.magic(e, p, 50f);
                Vec3d off = e.getPos().subtract(c);
                Vec3d h = new Vec3d(off.x, 0, off.z).normalize().multiply(0.8);
                e.setVelocity(h.x, 0.5, h.z);
                e.velocityModified = true;
            }
            Fx.puff(w, ParticleTypes.EXPLOSION, c, 3, 1, 0);
            Fx.sound(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1f);
            return true;
        }),
        new Ability("Зелье ускорения", "Скорость II и Спешка союзникам в радиусе 8 на 10 сек", 25, 20, false, (p, w) -> {
            for (ServerPlayerEntity a : Fx.allies(w, p, 8)) {
                Fx.buff(a, StatusEffects.SPEED, 10, 1);
                Fx.buff(a, StatusEffects.HASTE, 10, 1);
            }
            Fx.puff(w, ParticleTypes.EFFECT, p.getPos().add(0, 1, 0), 40, 1, 0.1);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_GENERIC_DRINK, 1f);
            return true;
        }),
        new Ability("Фантомный эликсир", "10 сек невидимости", 35, 20, false, (p, w) -> {
            Fx.buff(p, StatusEffects.INVISIBILITY, 10, 0);
            Fx.buff(p, StatusEffects.SPEED, 10, 0);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_GENERIC_DRINK, 0.7f);
            return true;
        }),
        new Ability("Великий эксперимент", "случайный мощный эффект одной из школ алхимии", 120, 80, true, (p, w) -> {
            Vec3d c = Fx.aimPoint(p, 12);
            switch (p.getRandom().nextInt(4)) {
                case 0 -> { // яд и увядание
                    for (LivingEntity e : Fx.around(w, c, 8, p)) { Fx.buff(e, StatusEffects.POISON, 8, 2); Fx.buff(e, StatusEffects.WITHER, 6, 1); }
                    Fx.puff(w, ParticleTypes.SQUID_INK, c, 100, 3, 0.1);
                }
                case 1 -> { // взрыв
                    for (LivingEntity e : Fx.around(w, c, 6, p)) Fx.magic(e, p, 100f);
                    Fx.puff(w, ParticleTypes.EXPLOSION_EMITTER, c, 1, 0, 0);
                    Fx.sound(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.8f);
                }
                case 2 -> { // исцеление
                    for (ServerPlayerEntity a : Fx.allies(w, p, 12)) {
                        a.heal(20f);
                        Fx.buff(a, StatusEffects.REGENERATION, 10, 2);
                        Fx.buff(a, StatusEffects.ABSORPTION, 15, 2);
                    }
                    Fx.puff(w, ParticleTypes.HAPPY_VILLAGER, p.getPos().add(0, 1, 0), 80, 3, 0.1);
                }
                default -> { // молния и огонь
                    for (LivingEntity e : Fx.around(w, c, 6, p)) { e.setOnFireFor(6); Fx.magic(e, p, 40f); }
                    bolt(w, p, c);
                }
            }
            return true;
        })
    );

    // ───────────── ДРУИД ─────────────
    public static final List<Ability> DRUID = List.of(
        new Ability("Хватка корней", "20 урона и обездвиживание на 4 сек", 12, 15, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 12);
            if (t == null) return false;
            Fx.magic(t, p, 20f);
            Fx.buff(t, StatusEffects.SLOWNESS, 4, 6);
            Fx.puff(w, ParticleTypes.COMPOSTER, t.getPos().add(0, 0.5, 0), 40, 0.5, 0.1);
            Fx.sound(w, t.getPos(), SoundEvents.BLOCK_ROOTS_PLACE, 1f);
            return true;
        }),
        new Ability("Целебная роща", "восстанавливает здоровье союзникам в радиусе 8", 30, 25, false, (p, w) -> {
            for (ServerPlayerEntity a : Fx.allies(w, p, 8)) {
                a.heal(6f);
                Fx.buff(a, StatusEffects.REGENERATION, 6, 2);
                Fx.puff(w, ParticleTypes.HAPPY_VILLAGER, a.getPos().add(0, 1, 0), 15, 0.4, 0.1);
            }
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_AZALEA_LEAVES_PLACE, 1f);
            return true;
        }),
        new Ability("Звериная форма", "15 сек: медведь — вы больше, сильнее и прочнее", 40, 30, false, (p, w) -> {
            EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
            Identifier id = Identifier.of(ArcanaMod.MOD_ID, "bear_form");
            if (inst != null) {
                inst.removeModifier(id);
                inst.addTemporaryModifier(new EntityAttributeModifier(id, 0.3, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
                Scheduler.later(w.getServer(), 300, () -> inst.removeModifier(id));
            }
            Fx.buff(p, StatusEffects.STRENGTH, 15, 1);
            Fx.buff(p, StatusEffects.RESISTANCE, 15, 0);
            Fx.buff(p, StatusEffects.HEALTH_BOOST, 15, 1);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_POLAR_BEAR_WARNING, 0.8f);
            return true;
        }),
        new Ability("Токсичные споры", "яд и замедление врагам в радиусе 6", 20, 20, false, (p, w) -> {
            List<LivingEntity> es = Fx.around(w, p.getPos(), 6, p);
            if (es.isEmpty()) return false;
            for (LivingEntity e : es) { Fx.buff(e, StatusEffects.POISON, 6, 1); Fx.buff(e, StatusEffects.SLOWNESS, 4, 1); }
            Fx.puff(w, ParticleTypes.SPORE_BLOSSOM_AIR, p.getPos().add(0, 1, 0), 100, 3, 0.05);
            return true;
        }),
        new Ability("Пробуждение леса", "призывает гигантского древня на 30 сек, лечит союзников", 120, 80, true, (p, w) -> {
            MobEntity t = Minions.spawn(p, EntityType.IRON_GOLEM, "Древень", 30, 2.5, false);
            if (t != null) { Fx.buff(t, StatusEffects.RESISTANCE, 30, 1); Fx.buff(t, StatusEffects.STRENGTH, 30, 2); }
            for (ServerPlayerEntity a : Fx.allies(w, p, 12)) { a.heal(10f); Fx.buff(a, StatusEffects.REGENERATION, 8, 1); }
            Fx.puff(w, ParticleTypes.HAPPY_VILLAGER, p.getPos().add(0, 1, 0), 150, 3, 0.2);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 0.6f);
            return true;
        })
    );

    // ───────────── ХРОНОМАГ ─────────────
    public static final List<Ability> CHRONOMAGE = List.of(
        new Ability("Остановка", "замораживает врагов в радиусе 8 на 4 сек", 25, 25, false, (p, w) -> {
            List<LivingEntity> es = Fx.around(w, p.getPos(), 8, p);
            if (es.isEmpty()) return false;
            for (LivingEntity e : es) freeze(w, e, 4);
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, 0.6f);
            return true;
        }),
        new Ability("Откат", "возвращает вас на позицию 5 секунд назад", 30, 20, false, (p, w) -> {
            Vec3d back = CastManager.rewindPoint(p);
            if (back == null) return false;
            Fx.puff(w, ParticleTypes.REVERSE_PORTAL, p.getPos().add(0, 1, 0), 40, 0.4, 0.3);
            p.requestTeleport(back.x, back.y, back.z);
            p.fallDistance = 0;
            Fx.puff(w, ParticleTypes.REVERSE_PORTAL, back.add(0, 1, 0), 40, 0.4, 0.3);
            Fx.sound(w, back, SoundEvents.BLOCK_BEACON_DEACTIVATE, 1.5f);
            return true;
        }),
        new Ability("Ускорение", "10 сек: Спешка III и Скорость II", 30, 20, false, (p, w) -> {
            Fx.buff(p, StatusEffects.HASTE, 10, 2);
            Fx.buff(p, StatusEffects.SPEED, 10, 1);
            Fx.puff(w, ParticleTypes.ENCHANT, p.getPos().add(0, 1, 0), 40, 0.6, 0.5);
            return true;
        }),
        new Ability("Временная ловушка", "6 сек замедляет врагов в области (радиус 5)", 35, 25, false, (p, w) -> {
            Vec3d c = Fx.aimPoint(p, 15);
            pulses(w, 6, 20, () -> {
                for (LivingEntity e : Fx.around(w, c, 5, p)) Fx.buff(e, StatusEffects.SLOWNESS, 2, 4);
                Fx.puff(w, ParticleTypes.ENCHANT, c.add(0, 1, 0), 60, 3, 0.3);
            });
            Fx.sound(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.5f);
            return true;
        }),
        new Ability("Вечное мгновение", "останавливает всех врагов в радиусе 15 на 6 сек", 120, 80, true, (p, w) -> {
            for (LivingEntity e : Fx.around(w, p.getPos(), 15, p)) freeze(w, e, 6);
            Fx.buff(p, StatusEffects.HASTE, 6, 2);
            Fx.buff(p, StatusEffects.SPEED, 6, 2);
            Fx.puff(w, ParticleTypes.END_ROD, p.getPos().add(0, 1, 0), 150, 5, 0.05);
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, 0.5f);
            return true;
        })
    );
}
