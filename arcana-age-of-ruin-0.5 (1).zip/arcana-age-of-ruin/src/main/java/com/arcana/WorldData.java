package com.arcana;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Состояние мира мода, хранится в <мир>/arcana_world.json: влияние биомов и уже построенные структуры. */
public final class WorldData {
    public static final class Quest {
        public String type; public int goal, progress, reward; public boolean done;
    }
    public static final class Guild {
        public String name, leader;
        public Set<String> members = new HashSet<>();
        public int points, cycle;
        public java.util.List<Quest> quests = new java.util.ArrayList<>();
    }
    public static final class Rating {
        public String name; public int level = 1, bosses;
    }

    public static final class Data {
        public Map<String, Guild> guilds = new HashMap<>();
        public Map<String, String> memberGuild = new HashMap<>();
        public Map<String, Rating> ratings = new HashMap<>();
        public long seed = 0;
        public Map<String, Integer> influence = new HashMap<>();
        public Set<Long> done = new HashSet<>();
        public Map<String, double[]> home = new HashMap<>();
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static Data d = new Data();

    private static Path file(MinecraftServer s) { return s.getSavePath(WorldSavePath.ROOT).resolve("arcana_world.json"); }

    public static void load(MinecraftServer s) {
        try {
            Path f = file(s);
            if (Files.exists(f)) { Data x = GSON.fromJson(Files.readString(f), Data.class); if (x != null) d = x; }
        } catch (Exception e) { System.err.println("[arcana] не удалось прочитать arcana_world.json: " + e); }
        if (d.influence == null) d.influence = new HashMap<>();
        if (d.done == null) d.done = new HashSet<>();
        if (d.home == null) d.home = new HashMap<>();
        if (d.guilds == null) d.guilds = new HashMap<>();
        if (d.memberGuild == null) d.memberGuild = new HashMap<>();
        if (d.ratings == null) d.ratings = new HashMap<>();
        if (d.seed == 0) d.seed = s.getOverworld().getSeed() ^ 0x5DEECE66DL;
    }

    public static void save(MinecraftServer s) {
        try { Files.writeString(file(s), GSON.toJson(d)); }
        catch (Exception e) { System.err.println("[arcana] не удалось сохранить arcana_world.json: " + e); }
    }

    public static int influence(String biome) { return d.influence.getOrDefault(biome, 30); }
    public static void addInfluence(String biome, int delta) {
        d.influence.put(biome, Math.max(0, Math.min(100, influence(biome) + delta)));
    }
}
