package com.arcana;

import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

/**
 * Гильдии: общие задания, очки, уровень гильдии (+1% к силе магии за уровень, максимум +10%) и рейтинги.
 * Методы команд возвращают текст; если он начинается с «!», это ошибка.
 */
public final class Guilds {
    private static final Map<UUID, String> INVITES = new HashMap<>(); // кому -> в какую гильдию
    public static final int MAX_MEMBERS = 20;

    private static WorldData.Data d() { return WorldData.d; }

    public static WorldData.Guild of(ServerPlayerEntity p) {
        String g = d().memberGuild.get(p.getUuidAsString());
        return g == null ? null : d().guilds.get(g);
    }

    public static int level(WorldData.Guild g) { return 1 + g.points / 500; }

    public static double bonus(ServerPlayerEntity p) {
        WorldData.Guild g = of(p);
        return g == null ? 0 : Math.min(0.10, 0.01 * level(g));
    }

    // ───────────── управление ─────────────
    public static String create(ServerPlayerEntity p, String name) {
        if (of(p) != null) return "!Ты уже в гильдии.";
        if (name.length() < 3 || name.length() > 16) return "!Название: от 3 до 16 символов.";
        for (String k : d().guilds.keySet()) if (k.equalsIgnoreCase(name)) return "!Такая гильдия уже есть.";
        WorldData.Guild g = new WorldData.Guild();
        g.name = name; g.leader = p.getUuidAsString(); g.members.add(p.getUuidAsString());
        newQuests(g);
        d().guilds.put(name, g);
        d().memberGuild.put(p.getUuidAsString(), name);
        updateRating(p);
        return "§6Гильдия «" + name + "» создана. Задания: /arcana guild quests";
    }

    public static String invite(ServerPlayerEntity p, String target) {
        WorldData.Guild g = of(p);
        if (g == null) return "!Ты не в гильдии.";
        if (!g.leader.equals(p.getUuidAsString())) return "!Приглашать может только лидер.";
        if (g.members.size() >= MAX_MEMBERS) return "!В гильдии максимум " + MAX_MEMBERS + " участников.";
        ServerPlayerEntity t = p.getServer().getPlayerManager().getPlayer(target);
        if (t == null) return "!Игрок не в сети.";
        if (of(t) != null) return "!Он уже в гильдии.";
        INVITES.put(t.getUuid(), g.name);
        t.sendMessage(Text.literal("§6" + p.getName().getString() + " приглашает тебя в гильдию «" + g.name + "». Принять: /arcana guild accept"), false);
        return "Приглашение отправлено.";
    }

    public static String accept(ServerPlayerEntity p) {
        String name = INVITES.remove(p.getUuid());
        if (name == null) return "!Нет приглашений.";
        WorldData.Guild g = d().guilds.get(name);
        if (g == null) return "!Гильдия уже распущена.";
        if (of(p) != null) return "!Ты уже в гильдии.";
        if (g.members.size() >= MAX_MEMBERS) return "!Гильдия заполнена.";
        g.members.add(p.getUuidAsString());
        d().memberGuild.put(p.getUuidAsString(), name);
        updateRating(p);
        tell(p.getServer(), g, "§a" + p.getName().getString() + " вступил в гильдию!");
        return "Ты в гильдии «" + name + "».";
    }

    public static String leave(ServerPlayerEntity p) {
        WorldData.Guild g = of(p);
        if (g == null) return "!Ты не в гильдии.";
        if (g.leader.equals(p.getUuidAsString())) return "!Лидер не может выйти. Распусти гильдию: /arcana guild disband";
        remove(g, p.getUuidAsString());
        return "Ты покинул гильдию.";
    }

    public static String kick(ServerPlayerEntity p, String target) {
        WorldData.Guild g = of(p);
        if (g == null) return "!Ты не в гильдии.";
        if (!g.leader.equals(p.getUuidAsString())) return "!Исключать может только лидер.";
        for (String id : new ArrayList<>(g.members)) {
            WorldData.Rating r = d().ratings.get(id);
            if (r != null && target.equalsIgnoreCase(r.name) && !id.equals(g.leader)) { remove(g, id); return "Исключён: " + r.name; }
        }
        return "!Такого участника нет.";
    }

    public static String disband(ServerPlayerEntity p) {
        WorldData.Guild g = of(p);
        if (g == null) return "!Ты не в гильдии.";
        if (!g.leader.equals(p.getUuidAsString())) return "!Распустить может только лидер.";
        tell(p.getServer(), g, "§cГильдия «" + g.name + "» распущена.");
        for (String id : g.members) d().memberGuild.remove(id);
        d().guilds.remove(g.name);
        return "Гильдия распущена.";
    }

    private static void remove(WorldData.Guild g, String uuid) {
        g.members.remove(uuid);
        d().memberGuild.remove(uuid);
    }

    // ───────────── инфо и рейтинги ─────────────
    public static String info(ServerPlayerEntity p) {
        WorldData.Guild g = of(p);
        if (g == null) return "!Ты не в гильдии. /arcana guild create <название>";
        StringBuilder sb = new StringBuilder("§6Гильдия «" + g.name + "» §7ур. " + level(g) + " §8(" + g.points + " очков, бонус +" + Math.round(bonus(p) * 100) + "% к силе)");
        sb.append("\n§7Участники (").append(g.members.size()).append("/").append(MAX_MEMBERS).append("):");
        for (String id : g.members) {
            WorldData.Rating r = d().ratings.get(id);
            sb.append("\n§f  ").append(r == null ? id.substring(0, 6) : r.name).append(id.equals(g.leader) ? " §6★" : "")
              .append(r == null ? "" : " §8ур. " + r.level);
        }
        return sb.toString();
    }

    public static String quests(ServerPlayerEntity p) {
        WorldData.Guild g = of(p);
        if (g == null) return "!Ты не в гильдии.";
        StringBuilder sb = new StringBuilder("§6Задания гильдии (круг " + (g.cycle + 1) + "):");
        for (WorldData.Quest q : g.quests)
            sb.append("\n").append(q.done ? "§a✔ " : "§f• ").append(questName(q.type)).append(" §7").append(Math.min(q.progress, q.goal)).append("/").append(q.goal)
              .append(" §8(+").append(q.reward).append(" очков)");
        return sb.toString();
    }

    public static String top(boolean guilds) {
        StringBuilder sb = new StringBuilder();
        if (guilds) {
            sb.append("§6Топ гильдий:");
            List<WorldData.Guild> l = new ArrayList<>(d().guilds.values());
            l.sort((a, b) -> b.points - a.points);
            for (int i = 0; i < Math.min(10, l.size()); i++) sb.append("\n§f").append(i + 1).append(". ").append(l.get(i).name).append(" §7— ").append(l.get(i).points).append(" очков, ур. ").append(level(l.get(i)));
            if (l.isEmpty()) sb.append("\n§7Пока пусто.");
        } else {
            sb.append("§6Топ игроков:");
            List<WorldData.Rating> l = new ArrayList<>(d().ratings.values());
            l.sort((a, b) -> b.level != a.level ? b.level - a.level : b.bosses - a.bosses);
            for (int i = 0; i < Math.min(10, l.size()); i++) {
                WorldData.Rating r = l.get(i);
                sb.append("\n§f").append(i + 1).append(". ").append(r.name).append(" §7— ур. ").append(r.level).append(" (").append(Progression.rank(r.level)).append("), боссов: ").append(r.bosses);
            }
            if (l.isEmpty()) sb.append("\n§7Пока пусто.");
        }
        return sb.toString();
    }

    public static void chat(ServerPlayerEntity p, String msg) {
        WorldData.Guild g = of(p);
        if (g == null) { p.sendMessage(Text.literal("§cТы не в гильдии."), false); return; }
        tell(p.getServer(), g, "§8[" + g.name + "] §f" + p.getName().getString() + "§7: " + msg);
    }

    private static void tell(MinecraftServer s, WorldData.Guild g, String msg) {
        for (String id : g.members) {
            ServerPlayerEntity m = s.getPlayerManager().getPlayer(UUID.fromString(id));
            if (m != null) m.sendMessage(Text.literal(msg), false);
        }
    }

    public static void updateRating(ServerPlayerEntity p) {
        WorldData.Rating r = d().ratings.computeIfAbsent(p.getUuidAsString(), k -> new WorldData.Rating());
        r.name = p.getName().getString();
        r.level = CastManager.data(p).level();
    }

    // ───────────── задания ─────────────
    private static String questName(String t) {
        return switch (t) { case "KILL" -> "Охотники: победить врагов"; case "CAST" -> "Заклинатели: применить способности"; default -> "Убийцы чудовищ: победить боссов"; };
    }

    private static void newQuests(WorldData.Guild g) {
        double m = 1 + 0.25 * g.cycle;
        g.quests = new ArrayList<>();
        g.quests.add(quest("KILL", (int) (200 * m), (int) (150 * m)));
        g.quests.add(quest("CAST", (int) (150 * m), (int) (100 * m)));
        g.quests.add(quest("BOSS", (int) Math.ceil(2 * m), (int) (300 * m)));
    }

    private static WorldData.Quest quest(String type, int goal, int reward) {
        WorldData.Quest q = new WorldData.Quest();
        q.type = type; q.goal = goal; q.reward = reward;
        return q;
    }

    private static void progress(ServerPlayerEntity p, String type) {
        WorldData.Guild g = of(p);
        if (g == null) return;
        MinecraftServer s = p.getServer();
        boolean all = true;
        for (WorldData.Quest q : g.quests) {
            if (!q.done && q.type.equals(type)) {
                q.progress++;
                if (q.progress >= q.goal) {
                    q.done = true;
                    g.points += q.reward;
                    tell(s, g, "§6✔ Задание гильдии выполнено: " + questName(q.type) + " §7(+" + q.reward + " очков)");
                    for (String id : g.members) {
                        ServerPlayerEntity m = s.getPlayerManager().getPlayer(UUID.fromString(id));
                        if (m == null) continue;
                        Progression.giveXp(m, 500);
                        if (m.getRandom().nextInt(5) == 0) { ItemStack egg = Pets.randomEgg(m.getRandom()); if (!m.giveItemStack(egg)) m.dropItem(egg, false); }
                    }
                }
            }
            if (!q.done) all = false;
        }
        if (all) {
            g.cycle++;
            newQuests(g);
            tell(s, g, "§6Новый круг заданий гильдии! /arcana guild quests");
        }
    }

    public static void onKill(ServerPlayerEntity p) { progress(p, "KILL"); }
    public static void onCast(ServerPlayerEntity p) { progress(p, "CAST"); }
    public static void onBoss(ServerPlayerEntity p) {
        progress(p, "BOSS");
        WorldData.Rating r = d().ratings.computeIfAbsent(p.getUuidAsString(), k -> new WorldData.Rating());
        r.name = p.getName().getString();
        r.bosses++;
    }
}
