package com.arcana;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class PetEggItem extends Item {
    public PetEggItem(Settings s) { super(s); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
            String species = c == null ? "" : c.copyNbt().getString("species");
            String err = Pets.hatch(sp, species);
            if (err != null) sp.sendMessage(Text.literal("§c" + err), true);
            else stack.decrement(1);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
