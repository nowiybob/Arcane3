package com.arcana;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Сохраняемые данные игрока. */
public record PlayerData(String cls, double mana, int selected, int level, int xp, int points,
                         String spec, boolean trial, boolean awakened, int pw, int mn, int vt, int rg) {

    public static final PlayerData EMPTY = new PlayerData("", 0, 0, 1, 0, 0, "", false, false, 0, 0, 0, 0);

    public static final Codec<PlayerData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.optionalFieldOf("class", "").forGetter(PlayerData::cls),
            Codec.DOUBLE.optionalFieldOf("mana", 0.0).forGetter(PlayerData::mana),
            Codec.INT.optionalFieldOf("selected", 0).forGetter(PlayerData::selected),
            Codec.INT.optionalFieldOf("level", 1).forGetter(PlayerData::level),
            Codec.INT.optionalFieldOf("xp", 0).forGetter(PlayerData::xp),
            Codec.INT.optionalFieldOf("points", 0).forGetter(PlayerData::points),
            Codec.STRING.optionalFieldOf("spec", "").forGetter(PlayerData::spec),
            Codec.BOOL.optionalFieldOf("trial", false).forGetter(PlayerData::trial),
            Codec.BOOL.optionalFieldOf("awakened", false).forGetter(PlayerData::awakened),
            Codec.INT.optionalFieldOf("pw", 0).forGetter(PlayerData::pw),
            Codec.INT.optionalFieldOf("mn", 0).forGetter(PlayerData::mn),
            Codec.INT.optionalFieldOf("vt", 0).forGetter(PlayerData::vt),
            Codec.INT.optionalFieldOf("rg", 0).forGetter(PlayerData::rg)
    ).apply(i, PlayerData::new));

    public PlayerData withMana(double v) { return new PlayerData(cls, v, selected, level, xp, points, spec, trial, awakened, pw, mn, vt, rg); }
    public PlayerData withSelected(int v) { return new PlayerData(cls, mana, v, level, xp, points, spec, trial, awakened, pw, mn, vt, rg); }
    public PlayerData withProgress(int l, int x, int p) { return new PlayerData(cls, mana, selected, l, x, p, spec, trial, awakened, pw, mn, vt, rg); }
    public PlayerData withSpec(String v) { return new PlayerData(cls, mana, selected, level, xp, points, v, trial, awakened, pw, mn, vt, rg); }
    public PlayerData withTrial(boolean v) { return new PlayerData(cls, mana, selected, level, xp, points, spec, v, awakened, pw, mn, vt, rg); }
    public PlayerData withAwakened(boolean v) { return new PlayerData(cls, mana, selected, level, xp, points, spec, trial, v, pw, mn, vt, rg); }
    public PlayerData withSkills(int a, int b, int c, int d, int pts) { return new PlayerData(cls, mana, selected, level, xp, pts, spec, trial, awakened, a, b, c, d); }
}
