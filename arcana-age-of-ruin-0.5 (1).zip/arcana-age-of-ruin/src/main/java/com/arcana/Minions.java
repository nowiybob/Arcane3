package com.arcana;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Призванные существа: служат владельцу, не бьют его и союзников, исчезают по таймеру. */
public final class Minions {
    private static final class M {
        final MobEntity mob; final UUID owner; final long expire;
        M(MobEntity mob, UUID owner, long expire) { this.mob = mob; this.owner = owner; this.expire = expire; }
    }
    private static final List<M> ALL = new ArrayList<>();

    public static MobEntity spawn(ServerPlayerEntity p, EntityType<? extends MobEntity> type, String name,
                                  int lifeSec, double scale, boolean bow) {
        ServerWorld w = p.getServerWorld();
        MobEntity m = type.create(w);
        if (m == null) return null;
        double ang = p.getRandom().nextDouble() * Math.PI * 2;
        m.refreshPositionAndAngles(p.getX() + Math.cos(ang) * 2, p.getY(), p.getZ() + Math.sin(ang) * 2, p.getYaw(), 0);
        m.setCustomName(Text.literal("§b" + name));
        m.setCustomNameVisible(true);
        m.addCommandTag("arcana_minion");
        m.setPersistent();
        if (scale != 1.0) {
            EntityAttributeInstance sc = m.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
            if (sc != null) sc.setBaseValue(scale);
        }
        if (bow) m.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        if (type == EntityType.SKELETON || type == EntityType.ZOMBIE) {
            m.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET)); // не горят на солнце
            m.setEquipmentDropChance(EquipmentSlot.HEAD, 0f);
            m.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
        }
        double mult = CastManager.cls(p) == ArcanaClass.SUMMONER ? 1.5 : 1.0;
        w.spawnEntity(m);
        ALL.add(new M(m, p.getUuid(), p.getServer().getTicks() + (long) (lifeSec * 20 * mult)));
        Fx.puff(w, net.minecraft.particle.ParticleTypes.SOUL, m.getPos().add(0, 1, 0), 20, 0.4, 0.05);
        return m;
    }

    public static void dismiss(MobEntity m) {
        ALL.removeIf(x -> x.mob == m);
        if (m.isAlive()) m.discard();
    }

    public static boolean isMinion(Entity e) { return e.getCommandTags().contains("arcana_minion"); }

    /** UUID «хозяина»: для игрока — он сам, для миньона — владелец, иначе null. */
    public static UUID ownerOf(Entity e) {
        if (e instanceof ServerPlayerEntity sp) return sp.getUuid();
        if (!isMinion(e)) return null;
        for (M m : ALL) if (m.mob == e) return m.owner;
        return null;
    }

    public static ServerPlayerEntity ownerPlayer(MinecraftServer s, Entity e) {
        if (e == null) return null;
        UUID id = ownerOf(e);
        return id == null ? null : s.getPlayerManager().getPlayer(id);
    }

    public static void tick(MinecraftServer s) {
        if (s.getTicks() % 10 != 0) return;
        Iterator<M> it = ALL.iterator();
        while (it.hasNext()) {
            M m = it.next();
            ServerPlayerEntity o = s.getPlayerManager().getPlayer(m.owner);
            if (!m.mob.isAlive() || o == null || s.getTicks() > m.expire) {
                if (m.mob.isAlive()) m.mob.discard();
                it.remove();
                continue;
            }
            if (m.mob.getWorld() != o.getWorld()) { m.mob.discard(); it.remove(); continue; }
            ServerWorld w = (ServerWorld) m.mob.getWorld();
            LivingEntity tgt = null;
            LivingEntity last = o.getAttacking();
            if (last != null && last.isAlive() && o.age - o.getLastAttackTime() < 200 && ownerOf(last) == null) tgt = last;
            if (tgt == null) {
                double best = Double.MAX_VALUE;
                for (LivingEntity e : Fx.around(w, o.getPos(), 16, o)) {
                    if (!(e instanceof HostileEntity) || isMinion(e)) continue;
                    double d = e.squaredDistanceTo(m.mob);
                    if (d < best) { best = d; tgt = e; }
                }
            }
            if (tgt != null) m.mob.setTarget(tgt);
            else {
                LivingEntity cur = m.mob.getTarget();
                if (cur instanceof PlayerEntity || (cur != null && isMinion(cur))) m.mob.setTarget(null);
                double dist = m.mob.squaredDistanceTo(o);
                if (dist > 1600) m.mob.refreshPositionAndAngles(o.getX(), o.getY(), o.getZ(), 0, 0);
                else if (dist > 100) m.mob.getNavigation().startMovingTo(o, 1.2);
            }
        }
    }
}
