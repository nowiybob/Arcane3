package com.arcana;

public enum Rarity {
    COMMON("Обычное", 0xAAAAAA), UNCOMMON("Необычное", 0x55FF55), RARE("Редкое", 0x5555FF),
    EPIC("Эпическое", 0xAA55FF), LEGENDARY("Легендарное", 0xFFAA00), MYTHIC("Мифическое", 0xFF5555),
    PRIMAL("Первородное", 0xFF55FF);

    public final String label; public final int color;
    Rarity(String label, int color) { this.label = label; this.color = color; }
    public static Rarity of(int i) { return values()[Math.max(0, Math.min(values().length - 1, i))]; }
}
