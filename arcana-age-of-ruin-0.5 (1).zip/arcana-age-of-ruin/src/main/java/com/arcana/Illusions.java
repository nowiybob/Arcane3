package com.arcana;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Настоящие иллюзии Фантома: двойники в вашей броне, оттягивают врагов на себя и взрываются тенью. */
public final class Illusions {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
    private static final int LIFE_TICKS = 160; // 8 секунд

    public static void spawn(ServerPlayerEntity p, int count) {
        ServerWorld w = p.getServerWorld();
        MinecraftServer server = w.getServer();
        List<MobEntity> decoys = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            MobEntity m = Minions.spawn(p, EntityType.ZOMBIE, "Иллюзия " + p.getName().getString(), 9, 1.0, false);
            if (m == null) continue;
            m.addCommandTag("arcana_decoy");
            for (EquipmentSlot s : SLOTS) {
                ItemStack st = p.getEquippedStack(s);
                if (!st.isEmpty()) { m.equipStack(s, st.copy()); m.setEquipmentDropChance(s, 0f); }
            }
            if (m.getEquippedStack(EquipmentSlot.HEAD).isEmpty()) m.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            EntityAttributeInstance hp = m.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (hp != null) { hp.setBaseValue(30); m.setHealth(30f); }
            Fx.buff(m, StatusEffects.SPEED, 9, 1);
            decoys.add(m);
        }
        if (decoys.isEmpty()) return;

        for (int t = 0; t < 8; t++) Scheduler.later(server, t * 20, () -> {
            for (LivingEntity e : Fx.around(w, p.getPos(), 18, p)) {
                if (!(e instanceof MobEntity mob) || Minions.isMinion(mob)) continue;
                MobEntity best = null;
                for (MobEntity d : decoys) if (d.isAlive() && (best == null || d.squaredDistanceTo(mob) < best.squaredDistanceTo(mob))) best = d;
                if (best != null) mob.setTarget(best);
            }
        });
        Scheduler.later(server, LIFE_TICKS, () -> {
            for (MobEntity d : decoys) if (d.isAlive()) { burst(w, p, d.getPos()); d.discard(); }
        });
    }

    /** Взрыв тени: 25 урона врагам в радиусе 4. */
    public static void burst(ServerWorld w, ServerPlayerEntity owner, Vec3d pos) {
        if (owner != null) for (LivingEntity e : Fx.around(w, pos, 4, owner)) {
            if (Minions.ownerOf(e) != null) continue;
            Fx.magic(e, owner, 25f);
            Fx.buff(e, StatusEffects.BLINDNESS, 2, 0);
        }
        Fx.puff(w, ParticleTypes.LARGE_SMOKE, pos.add(0, 1, 0), 40, 0.6, 0.05);
        Fx.puff(w, ParticleTypes.SOUL, pos.add(0, 1, 0), 20, 0.5, 0.1);
        Fx.sound(w, pos, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.6f);
    }
}
