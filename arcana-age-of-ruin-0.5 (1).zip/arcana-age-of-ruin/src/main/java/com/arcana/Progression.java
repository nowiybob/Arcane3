package com.arcana;

import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Уровни, ранги, очки навыков, специализации, пробуждение. */
public final class Progression {
    public static final int MAX_LEVEL = 100;
    public static final String[] RANKS = {"F", "E", "D", "C", "B", "A", "S", "SS", "SSS"};
    public static final String[] RANK_NAMES = {"новичок", "ученик", "практик", "специалист", "эксперт", "мастер", "легенда", "мифический", "первородный"};
    public static final int[] RANK_LEVEL = {1, 5, 10, 20, 30, 45, 60, 80, 100};
    public static final int[] SLOT_UNLOCK = {1, 3, 6, 10, 15};
    public static final int SKILL_CAP = 20;
    public static final int SPEC_LEVEL = 20, TRIAL_LEVEL = 50, AWAKEN_LEVEL = 60;
    private static final Identifier HP_ID = Identifier.of(ArcanaMod.MOD_ID, "level_health");

    public static int rankIndex(int lvl) {
        int r = 0;
        for (int i = 0; i < RANK_LEVEL.length; i++) if (lvl >= RANK_LEVEL[i]) r = i;
        return r;
    }
    public static String rank(int lvl) { return RANKS[rankIndex(lvl)]; }
    public static int xpToNext(int lvl) { return 80 + 20 * lvl + lvl * lvl / 2; }

    public static void giveXp(ServerPlayerEntity p, int amount) {
        PlayerData d = CastManager.data(p);
        if (d.cls().isEmpty() || amount <= 0) return;
        int lvl = d.level(), xp = d.xp() + amount, pts = d.points();
        int oldRank = rankIndex(lvl);
        boolean up = false;
        while (lvl < MAX_LEVEL && xp >= xpToNext(lvl)) { xp -= xpToNext(lvl); lvl++; pts++; up = true; }
        if (lvl >= MAX_LEVEL) xp = 0;
        CastManager.save(p, d.withProgress(lvl, xp, pts));
        if (up) {
            applyStats(p);
            Guilds.updateRating(p);
            p.sendMessage(Text.literal("§6⬆ Уровень " + lvl + " §7(ранг " + rank(lvl) + "). Очков навыков: " + pts), false);
            if (rankIndex(lvl) > oldRank) {
                p.getServer().getPlayerManager().broadcast(Text.literal("§d★ " + p.getName().getString() + " достиг ранга §l"
                        + rank(lvl) + " §r§d(" + RANK_NAMES[rankIndex(lvl)] + ")! Открыты новые задания и испытания."), false);
            }
            Fx.puff(p.getServerWorld(), ParticleTypes.TOTEM_OF_UNDYING, p.getPos().add(0, 1, 0), 40, 0.5, 0.3);
            Fx.sound(p.getServerWorld(), p.getPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, 1f);
        }
    }

    public static double maxMana(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        return 100 + 3.0 * (d.level() - 1) + 5.0 * d.mn() + Artifacts.sum(p, Artifacts.Kind.MANA);
    }

    /** Мана в секунду. */
    public static double regen(ServerPlayerEntity p, ArcanaClass c) {
        PlayerData d = CastManager.data(p);
        double r = (2.0 + 0.03 * d.level() + 0.3 * d.rg() + Artifacts.sum(p, Artifacts.Kind.REGEN)) * c.manaRegenMult;
        if ("focus".equals(d.spec())) r *= 1.25;
        if (c == ArcanaClass.SOLARIS && p.getServerWorld().isDay() && p.getServerWorld().isSkyVisible(p.getBlockPos())) r *= 1.5;
        return r;
    }

    public static double power(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        double m = 1 + 0.015 * (d.level() - 1) + 0.05 * d.pw();
        if ("power".equals(d.spec())) m *= 1.15;
        if (d.awakened()) m *= 1.5;
        m += Weapons.powerBonus(p) + FallOfCreation.partyBonus(p) + Artifacts.sum(p, Artifacts.Kind.POWER) + Guilds.bonus(p);
        return m;
    }

    public static double costMult(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        double m = 1;
        if ("focus".equals(d.spec())) m *= 0.85;
        if (d.awakened()) m *= 0.8;
        return m;
    }

    public static double cdMult(ServerPlayerEntity p, ArcanaClass c) {
        PlayerData d = CastManager.data(p);
        double m = c.cdMult;
        if ("haste".equals(d.spec())) m *= 0.8;
        if (d.awakened()) m *= 0.85;
        m *= 1 - Math.min(0.4, Artifacts.sum(p, Artifacts.Kind.COOLDOWN));
        return m;
    }

    private static final Identifier SPEED_ID = Identifier.of(ArcanaMod.MOD_ID, "artifact_speed");

    public static void applyStats(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        EntityAttributeInstance hp = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (hp != null) {
            hp.removeModifier(HP_ID);
            double bonus = Artifacts.sum(p, Artifacts.Kind.HEALTH);
            if (!d.cls().isEmpty()) bonus += 0.25 * (d.level() - 1) + 2.0 * d.vt();
            if (bonus > 0) hp.addPersistentModifier(new EntityAttributeModifier(HP_ID, bonus, EntityAttributeModifier.Operation.ADD_VALUE));
        }
        EntityAttributeInstance sp = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (sp != null) {
            sp.removeModifier(SPEED_ID);
            double v = Artifacts.sum(p, Artifacts.Kind.SPEED);
            if (v > 0) sp.addPersistentModifier(new EntityAttributeModifier(SPEED_ID, v, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    public static String spendSkill(ServerPlayerEntity p, String skill) {
        PlayerData d = CastManager.data(p);
        if (d.cls().isEmpty()) return "Сначала выбери класс.";
        if (d.points() <= 0) return "Нет очков навыков.";
        int pw = d.pw(), mn = d.mn(), vt = d.vt(), rg = d.rg();
        switch (skill) {
            case "power" -> { if (pw >= SKILL_CAP) return "Навык уже максимальный."; pw++; }
            case "mana" -> { if (mn >= SKILL_CAP) return "Навык уже максимальный."; mn++; }
            case "vitality" -> { if (vt >= SKILL_CAP) return "Навык уже максимальный."; vt++; }
            case "regen" -> { if (rg >= SKILL_CAP) return "Навык уже максимальный."; rg++; }
            default -> { return "Навыки: power, mana, vitality, regen"; }
        }
        CastManager.save(p, d.withSkills(pw, mn, vt, rg, d.points() - 1));
        applyStats(p);
        return null;
    }

    public static String chooseSpec(ServerPlayerEntity p, String spec) {
        PlayerData d = CastManager.data(p);
        if (d.cls().isEmpty()) return "Сначала выбери класс.";
        if (d.level() < SPEC_LEVEL) return "Специализация доступна с уровня " + SPEC_LEVEL + ".";
        if (!spec.equals("power") && !spec.equals("focus") && !spec.equals("haste"))
            return "Специализации: power (+15% урона), focus (−15% маны, +25% регена), haste (−20% перезарядки).";
        CastManager.save(p, d.withSpec(spec));
        return null;
    }

    public static String awaken(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        ArcanaClass c = ArcanaClass.byId(d.cls());
        if (c == null) return "Сначала выбери класс.";
        if (d.awakened()) return "Ты уже пробуждён.";
        if (d.level() < AWAKEN_LEVEL) return "Нужен уровень " + AWAKEN_LEVEL + ".";
        if (!d.trial()) return "Сначала пройди классовое испытание: /arcana trial (уровень " + TRIAL_LEVEL + "+).";
        CastManager.save(p, d.withAwakened(true));
        p.getServer().getPlayerManager().broadcast(Text.literal("§6✦ " + p.getName().getString() + " пробудил форму: §l" + c.awakening), false);
        Fx.puff(p.getServerWorld(), ParticleTypes.END_ROD, p.getPos().add(0, 1, 0), 150, 1.5, 0.3);
        Fx.sound(p.getServerWorld(), p.getPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1f);
        return null;
    }

    public static String sheet(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        ArcanaClass c = ArcanaClass.byId(d.cls());
        if (c == null) return "Класс не выбран.";
        int r = rankIndex(d.level());
        return "§6" + c.displayName + (d.awakened() ? " §d[" + c.awakening + "]" : "")
                + "\n§7Уровень §f" + d.level() + (d.level() < MAX_LEVEL ? " §8(" + d.xp() + "/" + xpToNext(d.level()) + " XP)" : " §8(макс.)")
                + "\n§7Ранг §f" + RANKS[r] + " §8(" + RANK_NAMES[r] + ")"
                + "\n§7Мана §f" + (int) d.mana() + "/" + (int) maxMana(p) + " §8(реген " + String.format("%.1f", regen(p, c)) + "/с)"
                + "\n§7Сила магии §f×" + String.format("%.2f", power(p))
                + "\n§7Очки навыков §f" + d.points() + " §8[power " + d.pw() + ", mana " + d.mn() + ", vitality " + d.vt() + ", regen " + d.rg() + "]"
                + "\n§7Специализация §f" + (d.spec().isEmpty() ? "—" : d.spec())
                + "\n§7Испытание §f" + (d.trial() ? "пройдено" : "нет");
    }
}
