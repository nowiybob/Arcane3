package com.arcana;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ModItems {
    public static Item FOCUS, PET_EGG, ARTIFACT;
    public static final Map<String, Item> RESOURCES = new LinkedHashMap<>();
    public static final Map<ArcanaClass, Item> WEAPONS = new EnumMap<>(ArcanaClass.class);

    /** id → русское название (должно совпадать с lang). */
    public static final String[][] RES = {
        {"glacier_heart", "Сердце ледника"}, {"flame_core", "Ядро пламени"}, {"eternal_life_seed", "Семя вечной жизни"},
        {"infinity_shard", "Осколок бесконечности"}, {"eternity_feather", "Перо вечности"}, {"ocean_heart", "Сердце океана"},
        {"thunder_core", "Грозовое ядро"}, {"eternity_sand", "Песок вечности"}, {"spore_heart", "Споровое сердце"},
        {"pure_crystal", "Чистейший кристалл"}, {"king_soul", "Душа короля"},
        {"fire_core", "Ядро огня"}, {"water_core", "Ядро воды"}, {"earth_core", "Ядро земли"}, {"air_core", "Ядро воздуха"}
    };

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(ArcanaMod.MOD_ID, id), item);
    }

    public static void init() {
        FOCUS = reg("arcana_focus", new FocusItem(new Item.Settings().maxCount(1)));
        PET_EGG = reg("pet_egg", new PetEggItem(new Item.Settings().maxCount(1)));
        ARTIFACT = reg("artifact", new ArtifactItem(new Item.Settings().maxCount(1)));
        for (String[] r : RES) RESOURCES.put(r[0], reg(r[0], new Item(new Item.Settings())));
        for (ArcanaClass c : ArcanaClass.values())
            WEAPONS.put(c, reg("weapon_" + c.id, new ClassWeaponItem(new Item.Settings().maxCount(1), c)));

        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(FOCUS))
                .displayName(Text.literal("Arcana: Age of Ruin"))
                .entries((ctx, entries) -> {
                    entries.add(FOCUS);
                    for (String sp : Pets.SPECIES.keySet()) entries.add(Pets.egg(sp));
                    for (String id : Artifacts.ALL.keySet()) entries.add(Artifacts.create(id, 3));
                    for (Item i : RESOURCES.values()) entries.add(i);
                    for (ArcanaClass c : ArcanaClass.values())
                        for (Rarity r : Rarity.values()) entries.add(Weapons.create(c, r));
                }).build();
        Registry.register(Registries.ITEM_GROUP, Identifier.of(ArcanaMod.MOD_ID, "main"), group);
    }
}
