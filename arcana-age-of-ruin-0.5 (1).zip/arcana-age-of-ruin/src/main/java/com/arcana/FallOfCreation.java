package com.arcana;

import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;

/**
 * Глобальный ивент THE FALL OF CREATION (5 этапов).
 * 1 Падение небес · 2 Стражи печатей · 3 Сердца мира · 4 Последняя армия · 5 Бог разрушения (арена в Энде).
 * Состояние хранится в памяти: перезапуск сервера прерывает ивент.
 */
public final class FallOfCreation {
    public enum Phase { IDLE, COUNTDOWN, S1, S2, S3, S4, S5, DONE }

    public static final long DEFAULT_COUNTDOWN_TICKS = 24L * 60 * 60 * 20; // 24:00:00
    private static final long LOSE_TIMEOUT_TICKS = 90L * 60 * 20;

    private static Phase phase = Phase.IDLE;
    private static long phaseStart, countdownEnd, eventStart, anomaliesUntil;
    private static int kills, killGoal, difficulty;
    private static final Set<UUID> participants = new HashSet<>();
    private static final Map<UUID, Object[]> origin = new HashMap<>(); // [ServerWorld, Vec3d]
    private static ServerBossBar bar;
    private static int guardiansAlive;
    private static Bosses.Boss god;
    private static long s5Start;

    public static Phase phase() { return phase; }

    // ───────────── управление ─────────────
    public static void start(MinecraftServer s, long countdownTicks) {
        if (phase != Phase.IDLE) return;
        phase = Phase.COUNTDOWN;
        phaseStart = s.getTicks();
        countdownEnd = s.getTicks() + countdownTicks;
        bar = new ServerBossBar(Text.literal("ДО ПОЛНОГО ПРОБУЖДЕНИЯ"), BossBar.Color.RED, BossBar.Style.PROGRESS);
        broadcast(s, "§5§lСИСТЕМА МИРА §r§c[КРИТИЧЕСКИЙ УРОВЕНЬ]\n§c§lОБНАРУЖЕНА УГРОЗА: КОНЕЦ ЭПОХИ\n§7Небесная печать разрушена.\n§7Древнее существо пробудилось.\n§7Все оставшиеся хранители должны объединиться.");
    }

    public static void stop(MinecraftServer s) {
        if (bar != null) bar.clearPlayers();
        phase = Phase.IDLE;
        participants.clear();
        if (god != null) Bosses.finish(god, s, false);
        god = null;
        returnPlayers(s);
        broadcast(s, "§7Ивент THE FALL OF CREATION остановлен.");
    }

    public static void skip(MinecraftServer s) {
        if (phase == Phase.COUNTDOWN) beginStage1(s);
    }

    public static void join(ServerPlayerEntity p) { participants.add(p.getUuid()); }

    public static String status(MinecraftServer s) {
        return switch (phase) {
            case IDLE -> "Ивент не активен.";
            case COUNTDOWN -> "Обратный отсчёт: " + fmt((countdownEnd - s.getTicks()) / 20);
            case S1 -> "Этап 1 «Падение небес»: " + kills + "/" + killGoal;
            case S2 -> "Этап 2 «Стражи печатей»: осталось стражей " + guardiansAlive;
            case S3 -> "Этап 3 «Сердца мира»: соберите по 1 ядру огня, воды, земли и воздуха и введите /arcana event restore";
            case S4 -> "Этап 4 «Последняя армия»: держитесь ещё " + fmt(Math.max(0, 240 - (s.getTicks() - phaseStart) / 20));
            case S5 -> "Этап 5 «Бог разрушения»: " + (god == null ? "—" : (int) Math.max(0, god.hp) + " HP");
            case DONE -> "Завершён.";
        };
    }

    private static String fmt(long sec) { return String.format("%02d:%02d:%02d", sec / 3600, sec % 3600 / 60, sec % 60); }

    private static void broadcast(MinecraftServer s, String msg) { s.getPlayerManager().broadcast(Text.literal(msg), false); }

    private static List<ServerPlayerEntity> online(MinecraftServer s) {
        List<ServerPlayerEntity> l = new ArrayList<>();
        for (UUID id : participants) { ServerPlayerEntity p = s.getPlayerManager().getPlayer(id); if (p != null) l.add(p); }
        return l;
    }

    /** Бонус силы: на этапе 4 за каждого союзника другого класса рядом +10% (до +40%). */
    public static double partyBonus(ServerPlayerEntity p) {
        if (phase != Phase.S4 && phase != Phase.S5) return 0;
        ArcanaClass mine = CastManager.cls(p);
        Set<ArcanaClass> seen = new HashSet<>();
        for (ServerPlayerEntity o : p.getServerWorld().getPlayers(x -> x != p && x.squaredDistanceTo(p) <= 400)) {
            ArcanaClass c = CastManager.cls(o);
            if (c != null && c != mine) seen.add(c);
        }
        return Math.min(0.4, 0.1 * seen.size());
    }

    // ───────────── этапы ─────────────
    private static void beginStage1(MinecraftServer s) {
        participants.clear();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) if (CastManager.cls(p) != null) participants.add(p.getUuid());
        phase = Phase.S1;
        phaseStart = s.getTicks();
        eventStart = s.getTicks();
        kills = 0;
        killGoal = (int) ((25 + 10 * participants.size()) * (1 + 0.25 * difficulty));
        broadcast(s, "§c§lЭТАП 1 — ПАДЕНИЕ НЕБЕС§r§7\nВ мире появляются разломы, из них выходят существа. Уничтожьте " + killGoal + ".");
    }

    private static void beginStage2(MinecraftServer s) {
        phase = Phase.S2;
        phaseStart = s.getTicks();
        List<ServerPlayerEntity> ps = online(s);
        if (ps.isEmpty()) { stop(s); return; }
        ServerPlayerEntity ref = ps.get(0);
        ServerWorld w = ref.getServerWorld();
        guardiansAlive = 0;
        String[] ids = {"guard_fire", "guard_water", "guard_earth", "guard_air"};
        for (int i = 0; i < 4; i++) {
            double a = i * Math.PI / 2;
            Vec3d pos = ref.getPos().add(Math.cos(a) * 14, 0, Math.sin(a) * 14);
            int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) pos.x, (int) pos.z);
            Bosses.spawn(Bosses.DEFS.get(ids[i]), w, new Vec3d(pos.x, y, pos.z), 1 + 0.25 * difficulty + 0.2 * (ps.size() - 1));
            guardiansAlive++;
        }
        broadcast(s, "§c§lЭТАП 2 — СТРАЖИ ПЕЧАТЕЙ§r§7\nЧетыре стража стихий вышли из разлома. Победите их — они хранят ядра стихий.");
    }

    private static void beginStage3(MinecraftServer s) {
        phase = Phase.S3;
        phaseStart = s.getTicks();
        broadcast(s, "§c§lЭТАП 3 — СЕРДЦА МИРА§r§7\nНужно найти четыре ядра стихий (огня, воды, земли, воздуха) и восстановить защиту мира: /arcana event restore");
    }

    private static void beginStage4(MinecraftServer s) {
        phase = Phase.S4;
        phaseStart = s.getTicks();
        broadcast(s, "§c§lЭТАП 4 — ПОСЛЕДНЯЯ АРМИЯ§r§7\nПоявилась огромная армия. Объединяйтесь в отряды — союзники других классов дают командные бонусы. Продержитесь 4 минуты.");
    }

    private static void beginStage5(MinecraftServer s) {
        phase = Phase.S5;
        phaseStart = s.getTicks();
        s5Start = s.getTicks();
        ServerWorld end = s.getWorld(World.END);
        if (end == null) { broadcast(s, "§cНе найден Энд — ивент прерван."); stop(s); return; }
        for (int dx = -16; dx <= 16; dx++) for (int dz = -16; dz <= 16; dz++)
            if (dx * dx + dz * dz <= 256) end.setBlockState(new BlockPos(dx, 100, dz), Blocks.OBSIDIAN.getDefaultState());
        List<ServerPlayerEntity> ps = online(s);
        for (ServerPlayerEntity p : ps) {
            origin.put(p.getUuid(), new Object[]{p.getServerWorld(), p.getPos()});
            p.teleport(end, 0.5, 101, -8.5, 0f, 0f);
        }
        double hpMult = Math.max(1, Math.min(10, ps.size())) / 10.0;
        god = Bosses.spawn(Bosses.DEFS.get("god"), end, new Vec3d(0.5, 101, 10.5), hpMult * (1 + 0.25 * difficulty));
        broadcast(s, "§4§lЭТАП 5 — БОГ РАЗРУШЕНИЯ§r§7\nВсе игроки отправлены в отдельное измерение. Финальный бой!");
    }

    private static void returnPlayers(MinecraftServer s) {
        for (Map.Entry<UUID, Object[]> e : origin.entrySet()) {
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(e.getKey());
            if (p == null) continue;
            ServerWorld w = (ServerWorld) e.getValue()[0];
            Vec3d v = (Vec3d) e.getValue()[1];
            p.teleport(w, v.x, v.y, v.z, p.getYaw(), p.getPitch());
        }
        origin.clear();
    }

    public static String restore(ServerPlayerEntity p) {
        if (phase != Phase.S3) return "Сейчас не этап «Сердца мира».";
        String[] cores = {"fire_core", "water_core", "earth_core", "air_core"};
        for (String c : cores) {
            Item it = ModItems.RESOURCES.get(c);
            if (p.getInventory().count(it) < 1) return "Не хватает: " + new ItemStack(it).getName().getString();
        }
        for (String c : cores) { Item it = ModItems.RESOURCES.get(c); p.getInventory().remove(st -> st.isOf(it), 1, p.getInventory()); }
        broadcast(p.getServer(), "§a" + p.getName().getString() + " восстановил защиту мира!");
        beginStage4(p.getServer());
        return null;
    }

    // ───────────── хуки ─────────────
    public static void onMobKilled(MinecraftServer s) {
        if (phase == Phase.S1) kills++;
    }

    public static void onBossDeath(String id, MinecraftServer s) {
        if (id.startsWith("guard_") && phase == Phase.S2) {
            guardiansAlive--;
            if (guardiansAlive <= 0) beginStage3(s);
        } else if (id.equals("god") && phase == Phase.S5) {
            win(s);
        }
    }

    private static void win(MinecraftServer s) {
        phase = Phase.DONE;
        god = null;
        broadcast(s, "§6§l✦ БОГ РАЗРУШЕНИЯ ПОВЕРЖЕН! §r§aМир получает благословение.");
        for (ServerPlayerEntity p : online(s)) {
            ArcanaClass c = CastManager.cls(p);
            Progression.giveXp(p, 5000);
            if (c != null) { ItemStack st = Weapons.create(c, Rarity.PRIMAL); if (!p.giveItemStack(st)) p.dropItem(st, false); }
            ItemStack heart = Artifacts.create("destroyer_heart", 6);
            if (!p.giveItemStack(heart)) p.dropItem(heart, false);
            Fx.buff(p, StatusEffects.STRENGTH, 3600, 0);
            Fx.buff(p, StatusEffects.RESISTANCE, 3600, 0);
            Fx.buff(p, StatusEffects.REGENERATION, 3600, 0);
        }
        Scheduler.later(s, 200, () -> { returnPlayers(s); cleanup(s); difficulty = 0; });
    }

    private static void lose(MinecraftServer s, String why) {
        phase = Phase.DONE;
        broadcast(s, "§4§l✖ ЭПОХА ПАЛА. §r§c" + why + " Мир получает постоянные магические аномалии. Следующий запуск ивента будет сложнее.");
        if (god != null) { Bosses.finish(god, s, false); god = null; }
        returnPlayers(s);
        anomaliesUntil = s.getTicks() + 60L * 60 * 20;
        difficulty = Math.min(5, difficulty + 1);
        cleanup(s);
    }

    private static void cleanup(MinecraftServer s) {
        if (bar != null) bar.clearPlayers();
        participants.clear();
        phase = Phase.IDLE;
    }

    // ───────────── тик ─────────────
    private static void spawnWave(MinecraftServer s, int perPlayer, double hpMult, boolean strong) {
        EntityType<?>[] light = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER};
        EntityType<?>[] heavy = {EntityType.VINDICATOR, EntityType.PILLAGER, EntityType.WITHER_SKELETON, EntityType.ZOMBIE};
        for (ServerPlayerEntity p : online(s)) {
            if (!p.isAlive()) continue;
            ServerWorld w = p.getServerWorld();
            for (int i = 0; i < perPlayer; i++) {
                double a = p.getRandom().nextDouble() * Math.PI * 2, d = 10 + p.getRandom().nextDouble() * 6;
                double x = p.getX() + Math.cos(a) * d, z = p.getZ() + Math.sin(a) * d;
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z);
                EntityType<?>[] pool = strong ? heavy : light;
                MobEntity m = (MobEntity) pool[p.getRandom().nextInt(pool.length)].create(w);
                if (m == null) continue;
                m.refreshPositionAndAngles(x, y, z, 0, 0);
                m.addCommandTag("arcana_event_mob");
                m.setCustomName(Text.literal("§5Порождение разлома"));
                m.setPersistent();
                EntityAttributeInstance hp = m.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                if (hp != null) { hp.setBaseValue(hp.getBaseValue() * hpMult); m.setHealth((float) hp.getBaseValue()); }
                m.setTarget(p);
                w.spawnEntity(m);
            }
        }
    }

    public static void tick(MinecraftServer s) {
        long now = s.getTicks();

        // аномалии после поражения
        if (anomaliesUntil > now && now % 400 == 0) {
            for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
                ServerWorld w = p.getServerWorld();
                LightningEntity l = EntityType.LIGHTNING_BOLT.create(w);
                if (l != null) {
                    l.refreshPositionAfterTeleport(p.getPos().add((p.getRandom().nextDouble() - 0.5) * 30, 0, (p.getRandom().nextDouble() - 0.5) * 30));
                    w.spawnEntity(l);
                }
                Fx.buff(p, StatusEffects.DARKNESS, 6, 0);
            }
        }

        if (phase == Phase.IDLE || phase == Phase.DONE) return;

        // полоска ивента
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) bar.addPlayer(p);
        double pct = 1;
        String title = "THE FALL OF CREATION";
        switch (phase) {
            case COUNTDOWN -> {
                long left = countdownEnd - now;
                pct = Math.max(0, Math.min(1, left / (double) (countdownEnd - phaseStart)));
                title = "§cДО ПОЛНОГО ПРОБУЖДЕНИЯ  §f" + fmt(left / 20);
                if (left <= 0) beginStage1(s);
            }
            case S1 -> {
                pct = Math.min(1, kills / (double) killGoal);
                title = "§cЭтап 1 · Падение небес §f" + kills + "/" + killGoal;
                if (now % 100 == 0) spawnWave(s, 3, 1 + 0.25 * difficulty, false);
                if (kills >= killGoal) {
                    broadcast(s, "§aРазломы закрыты!");
                    beginStage2(s);
                }
            }
            case S2 -> { pct = guardiansAlive / 4.0; title = "§cЭтап 2 · Стражи печатей §f" + guardiansAlive + "/4"; }
            case S3 -> {
                title = "§cЭтап 3 · Сердца мира §f/arcana event restore";
                if (now % 200 == 0) spawnWave(s, 1, 1.0, false);
            }
            case S4 -> {
                long el = now - phaseStart;
                pct = Math.min(1, el / 4800.0);
                title = "§cЭтап 4 · Последняя армия §f" + fmt(Math.max(0, 240 - el / 20));
                if (now % 300 == 0) spawnWave(s, 5, 1.5 + 0.25 * difficulty, true);
                if (el >= 4800) { broadcast(s, "§aАрмия сломлена, но разлом расширяется..."); beginStage5(s); }
            }
            case S5 -> {
                pct = god == null ? 0 : Math.max(0, god.hp / god.maxHp);
                title = "§4Этап 5 · Бог разрушения";
                if (now - s5Start > 100) {
                    boolean anyAlive = false;
                    ServerWorld end = s.getWorld(World.END);
                    for (ServerPlayerEntity p : online(s)) if (p.isAlive() && p.getWorld() == end) { anyAlive = true; break; }
                    if (!anyAlive) lose(s, "Все защитники пали.");
                }
            }
            default -> {}
        }
        bar.setName(Text.literal(title));
        bar.setPercent((float) pct);

        if (phase != Phase.COUNTDOWN && now - eventStart > LOSE_TIMEOUT_TICKS) lose(s, "Время вышло.");
    }
}
