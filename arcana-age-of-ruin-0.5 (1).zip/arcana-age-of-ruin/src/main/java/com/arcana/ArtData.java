package com.arcana;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.List;

/** Надетые артефакты игрока (до 3). */
public record ArtData(List<Entry> list) {
    public record Entry(String id, int tier) {
        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("id").forGetter(Entry::id),
                Codec.INT.optionalFieldOf("tier", 0).forGetter(Entry::tier)
        ).apply(i, Entry::new));
    }
    public static final ArtData EMPTY = new ArtData(List.of());
    public static final Codec<ArtData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Entry.CODEC.listOf().optionalFieldOf("list", List.of()).forGetter(ArtData::list)
    ).apply(i, ArtData::new));
}
