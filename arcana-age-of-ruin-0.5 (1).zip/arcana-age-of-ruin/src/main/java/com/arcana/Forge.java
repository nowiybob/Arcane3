package com.arcana;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/** Ковка: повышает редкость оружия класса в основной руке, расходуя ресурсы боссов. */
public final class Forge {
    private record Cost(Item item, int n) {}

    private static List<Cost> costFor(int target) {
        List<Cost> c = new ArrayList<>();
        switch (target) {
            case 1 -> c.add(new Cost(Items.IRON_INGOT, 16));
            case 2 -> c.add(new Cost(Items.GOLD_INGOT, 8));
            case 3 -> c.add(new Cost(Items.DIAMOND, 8));
            case 4 -> c.add(new Cost(Items.NETHERITE_INGOT, 4));
            case 5 -> c.add(new Cost(Items.NETHER_STAR, 1));
            case 6 -> { c.add(new Cost(Items.NETHER_STAR, 2)); c.add(new Cost(ModItems.RESOURCES.get("infinity_shard"), 1)); c.add(new Cost(ModItems.RESOURCES.get("eternity_feather"), 1)); }
        }
        return c;
    }
    private static int anyResNeeded(int target) { return new int[]{0, 0, 1, 2, 4, 6, 6}[target]; }

    private static int countAnyRes(ServerPlayerEntity p) {
        int n = 0;
        for (int i = 0; i < 11; i++) n += p.getInventory().count(ModItems.RESOURCES.get(ModItems.RES[i][0]));
        return n;
    }

    public static String costText(int target) {
        StringBuilder sb = new StringBuilder();
        for (Cost c : costFor(target)) sb.append(c.n).append("× ").append(new ItemStack(c.item).getName().getString()).append(", ");
        if (anyResNeeded(target) > 0) sb.append(anyResNeeded(target)).append("× любой ресурс босса");
        return sb.toString().replaceAll(", $", "");
    }

    public static String upgrade(ServerPlayerEntity p) {
        ItemStack s = p.getMainHandStack();
        if (!(s.getItem() instanceof ClassWeaponItem w)) return "Возьми в основную руку оружие класса.";
        int r = Weapons.rarityOf(s);
        if (r >= 6) return "Оружие уже первородное.";
        int target = r + 1;
        for (Cost c : costFor(target)) if (p.getInventory().count(c.item) < c.n) return "Не хватает: " + costText(target);
        if (countAnyRes(p) < anyResNeeded(target)) return "Не хватает: " + costText(target);

        for (Cost c : costFor(target)) p.getInventory().remove(st -> st.isOf(c.item), c.n, p.getInventory());
        int left = anyResNeeded(target);
        for (int i = 0; i < 11 && left > 0; i++) {
            Item it = ModItems.RESOURCES.get(ModItems.RES[i][0]);
            int have = Math.min(left, p.getInventory().count(it));
            if (have > 0) { p.getInventory().remove(st -> st.isOf(it), have, p.getInventory()); left -= have; }
        }
        Weapons.init(s, w.weaponClass, Rarity.of(target));
        return null;
    }
}
